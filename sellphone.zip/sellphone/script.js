function openForm(formId) {
    document.getElementById(formId).style.display = "block";
}

function closeForm(formId) {
    document.getElementById(formId).style.display = "none";
}

function editProduct(button) {
    const row = button.closest('tr');
    const cells = row.getElementsByTagName('td');
    const form = document.getElementById('editProductForm');

    form.elements['editProductId'].value = row.rowIndex;
    form.elements['editProductName'].value = cells[0].innerText.trim();
    form.elements['editProductVisibility'].value = cells[1].querySelector('.status').classList.contains('public') ? 'public' : 'private';
    form.elements['editProductSKU'].value = cells[2].innerText.trim();
    form.elements['editProductStock'].value = cells[3].innerText.trim();
    form.elements['editProductPrice'].value = cells[4].innerText.trim();

    openForm('editProductForm');
}

function deleteProduct(button) {
    const row = button.closest('tr');
    row.remove();
}

function addProductToCategory(button) {
    openForm('addProductForm');
}

document.querySelectorAll('.form-container').forEach(function(form) {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const formId = form.parentNode.id;

        const productTable = document.getElementById('productTable').getElementsByTagName('tbody')[0];
        
        if (formId === 'addProductForm') {
            const newRow = productTable.insertRow();
            newRow.innerHTML = `
                <td>
                    <input type="checkbox">
                    <img src="https://via.placeholder.com/50" alt="${form.elements['productName'].value}">
                    ${form.elements['productName'].value}
                </td>
                <td><span class="status ${form.elements['productVisibility'].value}">${form.elements['productVisibility'].value.charAt(0).toUpperCase() + form.elements['productVisibility'].value.slice(1)}</span></td>
                <td>${form.elements['productSKU'].value}</td>
                <td>${form.elements['productStock'].value}</td>
                <td>MXN ${form.elements['productPrice'].value}</td>
                <td>
                    <button class="btn" onclick="editProduct(this)">Editar</button>
                    <button class="btn btn-danger" onclick="deleteProduct(this)">Eliminar</button>
                </td>
            `;
        } else if (formId === 'editProductForm') {
            const rowIndex = form.elements['editProductId'].value;
            const row = productTable.rows[rowIndex - 1];
            row.cells[0].innerHTML = `<input type="checkbox"><img src="https://via.placeholder.com/50" alt="${form.elements['editProductName'].value}">${form.elements['editProductName'].value}`;
            row.cells[1].innerHTML = `<span class="status ${form.elements['editProductVisibility'].value}">${form.elements['editProductVisibility'].value.charAt(0).toUpperCase() + form.elements['editProductVisibility'].value.slice(1)}</span>`;
            row.cells[2].innerText = form.elements['editProductSKU'].value;
            row.cells[3].innerText = form.elements['editProductStock'].value;
            row.cells[4].innerText = `MXN ${form.elements['editProductPrice'].value}`;
        }

        closeForm(formId);
    });
});
