<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sellphone - Inventario de Productos</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Productos</h1>
            <nav>
                <ul>
                    <li><a href="#">Físico</a></li>
                    <li><a href="#">Servicios</a></li>
                    <li><a href="#">Descargas</a></li>
                    <li><a href="#">Tarjetas de regalo</a></li>
                </ul>
            </nav>
            <div class="actions">
                <button class="btn" onclick="openForm('importForm')">Importar</button>
                <button class="btn add-product" onclick="openForm('addProductForm')">Agregar Producto</button>
            </div>
        </header>
        <main>
            <div class="search">
                <input type="text" placeholder="Buscar por productos, etiquetas, categorías">
            </div>
            <table id="productTable">
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Visibilidad</th>
                        <th>SKU</th>
                        <th>Existencias</th>
                        <th>Precio</th>
                        <th>Almacenamiento</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Los productos se agregarán aquí dinámicamente -->
                </tbody>
            </table>
            <div class="pagination">
                <span>1-4 de 4 productos</span>
            </div>
        </main>
    </div>

    <!-- Formulario para agregar producto -->
    <div id="addProductForm" class="form-popup">
        <form class="form-container" enctype="multipart/form-data">
            <h2>Agregar Producto</h2>
            <label for="productName"><b>Nombre del Producto</b></label>
            <input type="text" placeholder="Nombre del Producto" name="productName" required>

            <label for="productVisibility"><b>Visibilidad</b></label>
            <select name="productVisibility">
                <option value="public">Público</option>
                <option value="private">Privado</option>
            </select>

            <label for="productSKU"><b>SKU</b></label>
            <input type="text" placeholder="SKU" name="productSKU" required>

            <label for="productStock"><b>Existencias</b></label>
            <input type="number" placeholder="Existencias" name="productStock" required>

            <label for="productPrice"><b>Precio</b></label>
            <input type="text" placeholder="Precio" name="productPrice" required>

            <label for="productStorage"><b>Almacenamiento</b></label>
            <select name="productStorage">
                <option value="64">64 GB</option>
                <option value="256">256 GB</option>
                <option value="512">512 GB</option>
                <option value="1000">1 TB</option>
            </select>

            <label for="productImage"><b>Imagen del Producto</b></label>
            <input type="file" name="productImage" accept="image/*" onchange="previewImage(event, 'addProductImagePreview')">
            <img id="addProductImagePreview" style="display:none; max-width: 100%; height: auto;">

            <button type="submit" class="btn">Agregar Producto</button>
            <button type="button" class="cancel" onclick="closeForm('addProductForm')">Cancelar</button>
        </form>
    </div>

    <!-- Formulario para editar producto -->
    <div id="editProductForm" class="form-popup">
        <form class="form-container" enctype="multipart/form-data">
            <h2>Editar Producto</h2>
            <input type="hidden" name="editProductId">

            <label for="editProductName"><b>Nombre del Producto</b></label>
            <input type="text" placeholder="Nombre del Producto" name="editProductName" required>

            <label for="editProductVisibility"><b>Visibilidad</b></label>
            <select name="editProductVisibility">
                <option value="public">Público</option>
                <option value="private">Privado</option>
            </select>

            <label for="editProductSKU"><b>SKU</b></label>
            <input type="text" placeholder="SKU" name="editProductSKU" required>

            <label for="editProductStock"><b>Existencias</b></label>
            <input type="number" placeholder="Existencias" name="editProductStock" required>

            <label for="editProductPrice"><b>Precio</b></label>
            <input type="text" placeholder="Precio" name="editProductPrice" required>

            <label for="editProductStorage"><b>Almacenamiento</b></label>
            <select name="editProductStorage">
                <option value="64">64 GB</option>
                <option value="256">256 GB</option>
                <option value="512">512 GB</option>
                <option value="1000">1 TB</option>
            </select>

            <label for="editProductImage"><b>Imagen del Producto</b></label>
            <input type="file" name="editProductImage" accept="image/*" onchange="previewImage(event, 'editProductImagePreview')">

            <img id="editProductImagePreview" style="display:none; max-width: 100%; height: auto;">

            <button type="submit" class="btn">Guardar Cambios</button>
            <button type="button" class="cancel" onclick="closeForm('editProductForm')">Cancelar</button>
        </form>
    </div>

    <script src="script.js"></script>
</body>
</html>
