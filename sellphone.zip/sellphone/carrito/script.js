// Función para abrir un formulario
function openForm(formId) {
    document.getElementById(formId).style.display = "flex";
}

// Función para cerrar un formulario
function closeForm(formId) {
    document.getElementById(formId).style.display = "none";
}

// Función para mostrar la vista previa de la imagen
function previewImage(event, imagePreviewId) {
    const reader = new FileReader();
    reader.onload = function() {
        const preview = document.getElementById(imagePreviewId);
        preview.src = reader.result;
        preview.style.display = "block";
    }
    reader.readAsDataURL(event.target.files[0]);
}

// Función para editar un producto
function editProduct(button) {
    const row = button.closest('tr');
    const cells = row.getElementsByTagName('td');
    const form = document.getElementById('editProductForm');

    form.elements['editProductId'].value = row.rowIndex;
    form.elements['editProductName'].value = cells[0].innerText.trim();
    form.elements['editProductVisibility'].value = cells[1].querySelector('.status').classList.contains('public') ? 'public' : 'private';
    form.elements['editProductSKU'].value = cells[2].innerText.trim();
    form.elements['editProductStock'].value = cells[3].innerText.trim();
    form.elements['editProductPrice'].value = cells[4].innerText.trim().replace('MXN ', '');
    form.elements['editProductStorage'].value = cells[5].innerText.trim().replace(' GB', '');

    const img = cells[0].querySelector('img');
    const preview = document.getElementById('editProductImagePreview');
    preview.src = img.src;
    preview.style.display = 'block';

    openForm('editProductForm');
}

// Función para eliminar un producto
function deleteProduct(button) {
    const row = button.closest('tr');
    row.remove();
}

// Función para agregar un producto a la tabla
function addProductToCategory(button) {
    openForm('addProductForm');
}

// Añadir el evento submit a los formularios
document.querySelectorAll('.form-container').forEach(function(form) {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const formId = form.parentNode.id;
        const productTable = document.getElementById('productTable').getElementsByTagName('tbody')[0];

        if (formId === 'addProductForm') {
            const newRow = productTable.insertRow();
            const productImage = form.elements['productImage'].files[0];
            const productImageURL = productImage ? URL.createObjectURL(productImage) : 'https://via.placeholder.com/150';

            newRow.innerHTML = `
                <td>
                    <input type="checkbox">
                    <img src="${productImageURL}" alt="${form.elements['productName'].value}" style="width: 150px; height: auto;">
                    ${form.elements['productName'].value}
                </td>
                <td><span class="status ${form.elements['productVisibility'].value}">${form.elements['productVisibility'].value.charAt(0).toUpperCase() + form.elements['productVisibility'].value.slice(1)}</span></td>
                <td>${form.elements['productSKU'].value}</td>
                <td>${form.elements['productStock'].value}</td>
                <td>MXN ${form.elements['productPrice'].value}</td>
                <td>${form.elements['productStorage'].value} GB</td>
                <td>
                    <button class="btn" onclick="editProduct(this)">Editar</button>
                    <button class="btn btn-danger" onclick="deleteProduct(this)">Eliminar</button>
                </td>
            `;
        } else if (formId === 'editProductForm') {
            const rowIndex = form.elements['editProductId'].value;
            const row = productTable.rows[rowIndex - 1];
            const editProductImage = form.elements['editProductImage'].files[0];
            let editProductImageURL = row.cells[0].querySelector('img').src;

            if (editProductImage) {
                editProductImageURL = URL.createObjectURL(editProductImage);
            }

            row.cells[0].innerHTML = `<input type="checkbox"><img src="${editProductImageURL}" alt="${form.elements['editProductName'].value}" style="width: 150px; height: auto;">${form.elements['editProductName'].value}`;
            row.cells[1].innerHTML = `<span class="status ${form.elements['editProductVisibility'].value}">${form.elements['editProductVisibility'].value.charAt(0).toUpperCase() + form.elements['editProductVisibility'].value.slice(1)}</span>`;
            row.cells[2].innerText = form.elements['editProductSKU'].value;
            row.cells[3].innerText = form.elements['editProductStock'].value;
            row.cells[4].innerText = `MXN ${form.elements['editProductPrice'].value}`;
            row.cells[5].innerText = `${form.elements['editProductStorage'].value} GB`;
        }

        closeForm(formId);
    });
});
