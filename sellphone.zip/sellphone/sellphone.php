<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sellphone - Carrito de Compra</title>
    <link rel="stylesheet" href="styles.css">
    <script src="script.js" defer></script>
</head>
<body>
    <div class="container">
        <header>
            <h1>Sellphone</h1>
            <nav>
                <ul>
                    <li><a href="#">Tienda</a></li>
                    <li><a href="#">Acerca de</a></li>
                    <li><a href="#">Contacto</a></li>
                    <li><a href="#">Carrito (3)</a></li>
                </ul>
            </nav>
        </header>
        <main>
            <h2>Carrito de compra</h2>
            <div class="cart-item">
                <img src="https://via.placeholder.com/150" alt="Iphone 13 Pro">
                <div>
                    <h3>Iphone 13 Pro</h3>
                    <p>Color: Negro</p>
                    <div class="quantity">
                        <button class="decrement">-</button>
                        <span class="count">1</span>
                        <button class="increment">+</button>
                    </div>
                </div>
                <span class="price">$11,000.00</span>
                <button class="remove">&times;</button>
            </div>
            <div class="cart-item">
                <img src="https://via.placeholder.com/150" alt="Samsung z Flip 5">
                <div>
                    <h3>Samsung z Flip 5</h3>
                    <div class="quantity">
                        <button class="decrement">-</button>
                        <span class="count">2</span>
                        <button class="increment">+</button>
                    </div>
                </div>
                <span class="price">$32,000.00</span>
                <button class="remove">&times;</button>
            </div>
            <div class="subtotal">
                <span>Subtotal</span>
                <span>$43,000.00</span>
            </div>
            <button class="checkout">Área de pago</button>
        </main>
    </div>
</body>
</html>
